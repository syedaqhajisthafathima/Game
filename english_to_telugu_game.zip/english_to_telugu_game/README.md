# Word Target — English to Telugu

A beginner-friendly vocabulary quiz built with HTML, CSS, and vanilla JavaScript.

## Run the game
1. Extract `english_to_telugu_game.zip`.
2. Open the `english_to_telugu_game` folder.
3. Double-click `index.html` to open it in a modern browser.

No backend or package installation is required. Google Fonts are used if the computer is online; the game itself works without them.

## Files
- `index.html` — screens and layout
- `style.css` — styling and responsive layout
- `script.js` — vocabulary, random questions, score, lives, and results

## Customize
Add or edit entries in the `words` array in `script.js`. Each entry needs:
- `english`: English word
- `telugu`: Telugu translation
- `emoji`: visual cue
- `distractors`: three other Telugu options

This is a learning prototype. Review vocabulary and spelling with a fluent Telugu speaker before using it for formal teaching.
