const words = [
  { english: "Apple", telugu: "ఆపిల్", emoji: "🍎", distractors: ["అరటి", "పుస్తకం", "పువ్వు"] },
  { english: "Book", telugu: "పుస్తకం", emoji: "📘", distractors: ["చెట్టు", "నీరు", "కారు"] },
  { english: "House", telugu: "ఇల్లు", emoji: "🏠", distractors: ["కుక్క", "చంద్రుడు", "పాలు"] },
  { english: "Water", telugu: "నీరు", emoji: "💧", distractors: ["పువ్వు", "పుస్తకం", "సూర్యుడు"] },
  { english: "Tree", telugu: "చెట్టు", emoji: "🌳", distractors: ["ఇల్లు", "పిల్లి", "కారు"] },
  { english: "Dog", telugu: "కుక్క", emoji: "🐶", distractors: ["పిల్లి", "ఆపిల్", "చంద్రుడు"] },
  { english: "Cat", telugu: "పిల్లి", emoji: "🐱", distractors: ["కుక్క", "చెట్టు", "నీరు"] },
  { english: "Sun", telugu: "సూర్యుడు", emoji: "☀️", distractors: ["చంద్రుడు", "ఇల్లు", "పుస్తకం"] },
  { english: "Moon", telugu: "చంద్రుడు", emoji: "🌙", distractors: ["సూర్యుడు", "పాలు", "పువ్వు"] },
  { english: "Car", telugu: "కారు", emoji: "🚗", distractors: ["చెట్టు", "నీరు", "కుక్క"] }
];

const homeScreen = document.querySelector("#home-screen");
const gameScreen = document.querySelector("#game-screen");
const resultScreen = document.querySelector("#result-screen");
const scoreEl = document.querySelector("#score");
const livesEl = document.querySelector("#lives");
const countEl = document.querySelector("#question-count");
const progressBar = document.querySelector("#progress-bar");
const emojiEl = document.querySelector("#word-emoji");
const englishEl = document.querySelector("#english-word");
const optionsEl = document.querySelector("#options");
const feedbackEl = document.querySelector("#feedback");
const nextBtn = document.querySelector("#next-btn");

let questions = [];
let currentIndex = 0;
let score = 0;
let correctCount = 0;
let lives = 3;
let answered = false;

function shuffle(items) {
  const copy = [...items];
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
}

function showScreen(screen) {
  [homeScreen, gameScreen, resultScreen].forEach(el => el.classList.add("hidden"));
  screen.classList.remove("hidden");
}

function startGame() {
  questions = shuffle(words);
  currentIndex = 0;
  score = 0;
  correctCount = 0;
  lives = 3;
  updateStats();
  showScreen(gameScreen);
  renderQuestion();
}

function updateStats() {
  scoreEl.textContent = score;
  livesEl.textContent = lives;
  countEl.textContent = `${Math.min(currentIndex + 1, questions.length)} / ${questions.length}`;
  progressBar.style.width = `${(currentIndex / questions.length) * 100}%`;
}

function renderQuestion() {
  if (currentIndex >= questions.length || lives <= 0) {
    finishGame();
    return;
  }

  answered = false;
  const question = questions[currentIndex];
  emojiEl.textContent = question.emoji;
  englishEl.textContent = question.english;
  feedbackEl.textContent = "";
  feedbackEl.className = "feedback";
  nextBtn.classList.add("hidden");
  optionsEl.innerHTML = "";

  const choices = shuffle([question.telugu, ...question.distractors]);
  choices.forEach(choice => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "option";
    button.textContent = choice;
    button.lang = "te";
    button.addEventListener("click", () => chooseAnswer(button, choice, question));
    optionsEl.appendChild(button);
  });
  updateStats();
}

function chooseAnswer(button, choice, question) {
  if (answered) return;
  answered = true;
  const buttons = [...optionsEl.querySelectorAll("button")];
  buttons.forEach(btn => {
    btn.disabled = true;
    if (btn.textContent === question.telugu) btn.classList.add("correct");
  });

  if (choice === question.telugu) {
    score += 10;
    correctCount++;
    feedbackEl.textContent = `✓ Correct! ${question.english} = ${question.telugu}`;
    feedbackEl.classList.add("good");
  } else {
    lives--;
    button.classList.add("incorrect");
    feedbackEl.textContent = `Not quite! ${question.english} = ${question.telugu}`;
    feedbackEl.classList.add("bad");
  }

  updateStats();
  progressBar.style.width = `${((currentIndex + 1) / questions.length) * 100}%`;
  nextBtn.textContent = currentIndex === questions.length - 1 || lives === 0 ? "See my results →" : "Next question →";
  nextBtn.classList.remove("hidden");
}

function nextQuestion() {
  currentIndex++;
  if (currentIndex >= questions.length || lives <= 0) {
    finishGame();
  } else {
    renderQuestion();
  }
}

function finishGame() {
  showScreen(resultScreen);
  const totalAsked = Math.min(questions.length, currentIndex + (answered ? 1 : 0));
  const accuracy = totalAsked > 0 ? Math.round((correctCount / totalAsked) * 100) : 0;
  document.querySelector("#final-score").textContent = `${score} / 100`;
  document.querySelector("#correct-count").textContent = `${correctCount} / ${Math.max(1, totalAsked)}`;
  document.querySelector("#accuracy").textContent = `${accuracy}%`;

  let title = "Keep practicing!";
  let message = "Every round helps you learn a little more.";
  let emoji = "🌱";
  if (score >= 80) {
    title = "Amazing work!";
    message = "Fantastic! You're building a strong Telugu vocabulary.";
    emoji = "🏆";
  } else if (score >= 50) {
    title = "Great effort!";
    message = "You're getting there. Play again to learn even more.";
    emoji = "⭐";
  }
  document.querySelector("#result-title").textContent = title;
  document.querySelector("#result-message").textContent = message;
  document.querySelector("#result-emoji").textContent = emoji;
}

document.querySelector("#start-btn").addEventListener("click", startGame);
nextBtn.addEventListener("click", nextQuestion);
document.querySelector("#play-again-btn").addEventListener("click", startGame);
document.querySelector("#home-btn").addEventListener("click", () => showScreen(homeScreen));
document.querySelector("#quit-btn").addEventListener("click", () => {
  if (window.confirm("Exit this round and return home? Your current score will not be saved.")) {
    showScreen(homeScreen);
  }
});
